#ifndef __MAIN_HH__
#define __MAIN_HH__

#include <QApplication>

#include "application.hh"
#include "mainwindow.hh"

#endif

#include "module.hh"

Module::Module(QObject *parent) :
  QObject(parent)
{
  // Pass...
}

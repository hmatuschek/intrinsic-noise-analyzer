#include "savedialog.hh"


SaveDialog::SaveDialog(QWidget *parent) :
  QDialog(parent)
{

}

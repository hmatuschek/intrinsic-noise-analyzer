#ifndef MAIN_HH
#define MAIN_HH

#include "benchmark.hh"

#endif // MAIN_HH

#ifndef __CLI_SBML_FFT_HH__
#define __CLI_SBML_FFT_HH__

#include <iostream>
#include "fluctuator.hh"
#include <sbml/SBMLTypes.h>
#include <ginac/ginac.h>

#endif

#ifndef __CLI_SBML_LNA_TIME_HH__
#define __CLI_SBML_LNA_TIME_HH__

#include <iostream>
#include "fluctuator.hh"
#include <sbml/SBMLTypes.h>
#include <eigen3/Eigen/Eigen>
#include <ginac/ginac.h>

#endif

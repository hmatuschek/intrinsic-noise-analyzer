// List the contents of cl_asm_m68k.cc.

#define COPY_LOOPS
#define FILL_LOOPS
#define CLEAR_LOOPS
#define LOG_LOOPS
#define TEST_LOOPS
#define ADDSUB_LOOPS
#define SHIFT_LOOPS
#define MUL_LOOPS
#define DIV_LOOPS

// The endianness is irrelevant for that code:
#include "cl_asm_mips_.cc"

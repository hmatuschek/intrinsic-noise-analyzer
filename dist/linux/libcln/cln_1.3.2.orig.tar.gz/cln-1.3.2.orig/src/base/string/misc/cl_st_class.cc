// cl_class_string.

// General includes.
#include "base/cl_sysdep.h"

// Specification.
#include "cln/string.h"


// Implementation.

namespace cln {

cl_class cl_class_string = {
	NULL,		// empty destructor
	0
};

}  // namespace cln
